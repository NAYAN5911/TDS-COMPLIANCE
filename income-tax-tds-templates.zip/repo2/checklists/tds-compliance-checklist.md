# TDS Compliance Checklist

**Deductor:** ____  **TAN:** ____  **FY:** ____

## Every payment
- [ ] Identify nature of payment and correct section
- [ ] Check threshold (single/annual) and rate; lower/nil deduction certificate on file?
- [ ] PAN collected and validated (higher rate if missing/inoperative)
- [ ] Declarations obtained where relevant
- [ ] TDS deducted at the time of credit or payment, whichever is earlier

## Monthly
- [ ] TDS deposited by the due date (challan no., BSR code, date recorded)
- [ ] Interest on late deduction/deposit computed and paid
- [ ] Register updated (see `tds-templates/tds-register-and-calculator.xlsx`)

## Quarterly
- [ ] Quarterly return prepared and filed by due date
- [ ] Challan-wise statement matched with OLTAS
- [ ] Late filing fee considered

## After filing
- [ ] TDS certificates issued to deductees by due date
- [ ] Correction statements for defaults flagged in TRACES
- [ ] Default/demand check on TRACES
