# Tax Audit Checklist (Section 44AB)

- [ ] Applicability: turnover/receipts limits, presumptive scheme exclusions
- [ ] Appointment and engagement letter
- [ ] Books of account and documents maintained
- [ ] Report in prescribed forms (audit report and statement of particulars) prepared and uploaded
- [ ] Clause-wise points: loans/deposits in cash, payments over cash limits, TDS compliance, GST reconciliation, related party payments, depreciation, MSME payments
- [ ] Tax audit report e-filed by due date and accepted by assessee
- [ ] UDIN generated
