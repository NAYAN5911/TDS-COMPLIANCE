# ITR Filing Checklist (Individual / Professional)

- [ ] Choose correct ITR form; residential status
- [ ] PAN-Aadhaar linked; bank account pre-validated for refund
- [ ] Download Form 26AS, AIS and TIS; compare with books (see `form26as-ais-reconciliation.xlsx`)
- [ ] Income details: salary, house property, business/profession, capital gains, other sources
- [ ] Opening vs old/new regime comparison done; Form 10-IEA where required
- [ ] Deductions and proofs collected
- [ ] Advance tax and self-assessment tax paid; interest computed
- [ ] Foreign assets/income disclosure check
- [ ] Carry-forward losses and set-off schedules
- [ ] Verify return (e-verification) within the allowed time
- [ ] Save ITR-V / acknowledgement and computation file
