# Reply to Notice / Intimation - Template

**To:** [Assessing Officer / CPC / TRACES]  **Ref no. & date:** ____  **PAN/TAN:** ____  **FY/AY:** ____

## Subject: Reply to notice dated ____ regarding ____

**1. Facts**
[Chronology: payment dates, amounts, section applied, return filed on ____.]

**2. Reasons for default (if any) and rectification done**
[e.g., short deduction / late deposit / PAN error; corrective action taken with challan details.]

**3. Legal position**
[Relevant section/rule, CBDT circulars, case law with citations.]

**4. Documents enclosed**
- Annexure 1: Challan copy
- Annexure 2: Form 26AS / TRACES extract
- Annexure 3: Corrected statement acknowledgement

**5. Prayer**
Kindly drop the proposed demand / accept the explanation.

Date: ____  Place: ____  Authorised signatory: ____
