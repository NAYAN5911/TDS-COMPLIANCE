# How to Use

## TDS register
1. Fill `Assumptions` (yellow). Rates differ by section and year - enter the correct values per row.
2. Enter each payment in `Register`. Deposit due date, quarter, TDS and interest are formulas.
3. In `Quarterly Summary` type each section once in column A; the check cell must be 0.

## 26AS / AIS reconciliation
Enter deductor-wise amounts from 26AS/AIS and your books; differences are calculated. Record the action for each mismatch.

## Individual tax computation
Update the `Slabs` sheet and the rebate inputs for the year before relying on the result. Surcharge and marginal relief are not modelled.

## Publishing on GitHub
```
git init
git add .
git commit -m "Initial commit: income tax and TDS templates"
git branch -M main
git remote add origin https://github.com/<your-username>/income-tax-tds-templates.git
git push -u origin main
```
